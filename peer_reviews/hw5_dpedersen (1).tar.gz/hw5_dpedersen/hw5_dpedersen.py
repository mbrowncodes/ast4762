#!/usr/bin/env python
# coding: utf-8

# In[6]:


#Practicum 3
# Dalton Pedersen
# 09/27/26

import os
import numpy as np
import matplotlib.pyplot as plt
import scipy.special as ss
from linfit import linfit

# Set random seed for reproducibility
np.random.seed(42)

# ==============================================================================
# Helper Function: Read practicum3_1.dat
# ==============================================================================
def load_practicum_data(filename):
    """Parses practicum3_1.dat to extract Model 1 and Model 2 data."""
    x1, y1 = [], []
    x2, y2 = [], []
    current_model = None

    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                if 'Model 1' in line:
                    current_model = 1
                elif 'Model 2' in line:
                    current_model = 2
                continue

            parts = line.split()
            if len(parts) == 2:
                x_val, y_val = float(parts[0]), float(parts[1])
                if current_model == 1:
                    x1.append(x_val)
                    y1.append(y_val)
                elif current_model == 2:
                    x2.append(x_val)
                    y2.append(y_val)

    return np.array(x1), np.array(y1), np.array(x2), np.array(y2)


# Problem 1: Fitting Data
print("=" * 60)
print("PROBLEM 1: FITTING DATA WITH MODELS")
print("=" * 60)

data_file = 'practicum3_1.dat'
if os.path.exists(data_file):
    x1, y1, x2, y2 = load_practicum_data(data_file)
else:
    raise FileNotFoundError(f"Could not find {data_file} in current directory.")

# 1a. Plotting Data Set 1 (Model 1)
plt.figure(figsize=(8, 5))
plt.scatter(x1, y1, color='blue', alpha=0.7, edgecolors='k', label='Model 1 Data')
plt.title("Practicum 3 - Problem 1a: Model 1 Raw Data")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.savefig("p3_dpedersen_problem1a_model1_raw.png", dpi=300)
plt.close()
print("[1a] Saved plot: p3_dpedersen_problem1a_model1_raw.png")

# 1b. Fitting Linear Model to Data Set 1
sig_y = 0.5
a_fit1, b_fit1, sa1, sb1, chisq1, prob1, covar1, yfit1 = linfit(y1, x1, y_unc=sig_y)

print("\n--- 1b. Fitting Results for Data Set 1 (sigma_y = 0.5) ---")
print(f"Fitted Intercept (a): {a_fit1:.4f} +/- {sa1:.4f}  (True: 1.2)")
print(f"Fitted Slope (b):     {b_fit1:.4f} +/- {sb1:.4f}  (True: 3.2)")
print(f"Chi-Squared (chisq): {chisq1:.4f}")
print(f"Degrees of Freedom:   {len(x1) - 2}")

# 3 Sigma Parameter Verification
diff_a = abs(a_fit1 - 1.2)
diff_b = abs(b_fit1 - 3.2)
within_3sig_a = diff_a <= 3 * sa1
within_3sig_b = diff_b <= 3 * sb1
print(f"Intercept within 3-sigma of true value (1.2)? {within_3sig_a} (|diff| = {diff_a:.4f}, 3*sigma = {3*sa1:.4f})")
print(f"Slope within 3-sigma of true value (3.2)?     {within_3sig_b} (|diff| = {diff_b:.4f}, 3*sigma = {3*sb1:.4f})")

# Effect of changing uncertainties
_, _, sa_02, sb_02, chisq_02, prob_02, _, _ = linfit(y1, x1, y_unc=0.2)
_, _, sa_09, sb_09, chisq_09, prob_09, _, _ = linfit(y1, x1, y_unc=0.9)
print("\nUncertainty Sensitivity Analysis:")
print(f"  sigma_y = 0.2: sa = {sa_02:.4f}, sb = {sb_02:.4f}, chisq = {chisq_02:.2f}, prob = {prob_02:.4e}")
print(f"  sigma_y = 0.5: sa = {sa1:.4f}, sb = {sb1:.4f}, chisq = {chisq1:.2f}, prob = {prob1:.4f}")
print(f"  sigma_y = 0.9: sa = {sa_09:.4f}, sb = {sb_09:.4f}, chisq = {chisq_09:.2f}, prob = {prob_09:.4f}")

# 1c. Goodness of Fit Probability and Plot
print("\n--- 1c. Goodness-of-Fit Probability ---")
print(f"P(X^2 > {chisq1:.2f}): {prob1:.4f} ({prob1*100:.2f}%)")

# Sorting for smooth line plotting
sort_idx1 = np.argsort(x1)
x1_sorted = x1[sort_idx1]
yfit1_sorted = yfit1[sort_idx1]

plt.figure(figsize=(8, 5))
plt.errorbar(x1, y1, yerr=sig_y, fmt='o', color='tab:blue', ecolor='gray', 
             capsize=3, label='Data (sigma_y = 0.5)', alpha=0.7)
plt.plot(x1_sorted, yfit1_sorted, color='tab:red', linewidth=2, 
         label=f'Linear Fit: f(x) = {b_fit1:.2f}x + {a_fit1:.2f}')
plt.title(f"Model 1 Fit: Linear Data (chisq={chisq1:.2f}, p={prob1:.3f})")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.savefig("p3_dpedersen_problem1c_model1_fit.png", dpi=300)
plt.close()
print("[1c] Saved plot: problem1c_model1_fit.png")

# 1d. Repeat for Data Set 2 (Quadratic Model)
a_fit2, b_fit2, sa2, sb2, chisq2, prob2, covar2, yfit2 = linfit(y2, x2, y_unc=sig_y)

print("\n--- 1d. Fitting Linear Model to Data Set 2 (Quadratic Data) ---")
print(f"Fitted Intercept (a): {a_fit2:.4f} +/- {sa2:.4f}")
print(f"Fitted Slope (b):     {b_fit2:.4f} +/- {sb2:.4f}")
print(f"Chi-Squared (chisq): {chisq2:.4f}")
print(f"Probability (p-val): {prob2:.4e}")

sort_idx2 = np.argsort(x2)
x2_sorted = x2[sort_idx2]
yfit2_sorted = yfit2[sort_idx2]

plt.figure(figsize=(8, 5))
plt.errorbar(x2, y2, yerr=sig_y, fmt='s', color='tab:orange', ecolor='gray', 
             capsize=3, label='Data (sigma_y = 0.5)', alpha=0.7)
plt.plot(x2_sorted, yfit2_sorted, color='tab:red', linewidth=2, 
         label=f'Linear Fit: f(x) = {b_fit2:.2f}x + {a_fit2:.2f}')
plt.title(f"Model 2 Fit: Quadratic Data (chisq={chisq2:.1f}, p={prob2:.2e})")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.savefig("p3_dpedersen_problem1d_model2_fit.png", dpi=300)
plt.close()
print("[1d] Saved plot: p3_dpedersen_problem1d_model2_fit.png")


# Problem 2: Sigma Clipping

print("\n" + "=" * 60)
print("PROBLEM 2: SIGMA CLIPPING")
print("=" * 60)

# 2a. Array Generation
poisson_draws = np.random.poisson(lam=10000, size=396)
uniform_draws = np.random.uniform(low=0, high=1e6, size=4)
ccd_data = np.concatenate([poisson_draws, uniform_draws])

raw_mean = np.mean(ccd_data)
raw_median = np.median(ccd_data)

print(f"[2a] Raw Sample Statistics (400 elements):")
print(f"     Mean:   {raw_mean:.4f}")
print(f"     Median: {raw_median:.4f}")
print(f"     Expected Poisson Mean (N): 10000")
print(f"     -> The MEDIAN ({raw_median:.2f}) is much closer to N=10,000 than the mean ({raw_mean:.2f}).")

# 2b. Standard Deviation and 5-Sigma Masking
raw_std = np.std(ccd_data, ddof=1)
print(f"\n[2b] Raw Standard Deviation: {raw_std:.4f}")

# Single-line 5-sigma mask around median
clipped_data = ccd_data[np.abs(ccd_data - raw_median) <= 5 * raw_std]

new_mean = np.mean(clipped_data)
new_median = np.median(clipped_data)
new_std = np.std(clipped_data, ddof=1)

print(f"\n     Clipped Sample Statistics ({len(clipped_data)} elements remaining):")
print(f"     New Mean:   {new_mean:.4f}")
print(f"     New Median: {new_median:.4f}")
print(f"     New Std:    {new_std:.4f}")


# HW5 start


# Reusable Iterative Sigma Rejection Routine
def sigrej(data, rej_limits, mask=None):
    """
    Performs iterative sigma rejection to generate a boolean quality mask.
    """
    data = np.asarray(data)

    if mask is None:
        working_mask = np.ones(data.shape, dtype=bool)
    else:
        working_mask = np.array(mask, dtype=bool, copy=True)

    for n_sigma in rej_limits:
        good_data = data[working_mask]

        if len(good_data) == 0:
            break

        current_mean = np.mean(good_data)
        current_std = np.std(good_data, ddof=1)

        iter_mask = np.abs(data - current_mean) <= n_sigma * current_std
        working_mask = working_mask & iter_mask

    return working_mask


# Homework 5 - Problem 2: Second Pass (Using Practicum 3's `clipped_data`)
# Calculate Pass 1 statistics directly from Practicum 3's output variable
subsample = clipped_data
med_p1 = np.median(subsample)
std_p1 = np.std(subsample, ddof=1)

# Pass 2: 5-sigma clip around Pass 1 stats
pass2_mask = np.abs(subsample - med_p1) <= 5.0 * std_p1
sub_subsample = subsample[pass2_mask]

mean_p2 = np.mean(sub_subsample)
med_p2 = np.median(sub_subsample)
std_p2 = np.std(sub_subsample, ddof=1)

print(f"\n[HW5 2] Sub-subsample Pass 2 -> Count: {len(sub_subsample)}, Mean: {mean_p2:.2f}, Median: {med_p2:.2f}, Std: {std_p2:.2f}")
print(f"        Mean-Median diff: {abs(mean_p2 - med_p2):.4f}")
print(f"        Final Std vs Poisson Expected (sqrt(10000)=100): {std_p2:.4f}")


# Homework 5 - Problem 3: Test Reusable sigrej() Routine
sigrej_mask = sigrej(ccd_data, rej_limits=(5.0, 5.0))
cleaned_data = ccd_data[sigrej_mask]
cleaned_mean = np.mean(cleaned_data)

print(f"\n[HW5 3] sigrej() Routine -> Cleaned Count: {len(cleaned_data)}, Cleaned Mean: {cleaned_mean:.2f}")
assert np.isclose(cleaned_mean, mean_p2), "Mismatch between manual clipping and sigrej()!"
print("        Verification Successful: sigrej() matches manual output!")


# In[2]:


# 2a. Raw Data Comparison to N = 10,000:
#     Raw Mean:   19777.01
#     Raw Median: 10006.50
#     The MEDIAN is much closer to N=10,000 because the median is a robust 
#     statistic that is unaffected by the extreme high-value cosmic ray outliers 
#     (up to 1,000,000), whereas the mean is heavily skewed upward.

# 2b. Sigma Clipping Effect:
#     Raw Standard Deviation: 98114.78
#     Clipped Mean:           9997.43
#     Clipped Median:         10006.50
#     Clipped Standard Dev:   99.58
#
#     What happened?
#     1. The 4 bad pixel outliers were completely removed from the array because their values fell far beyond median + 5*sigma (490,000 threshold).
#     2. The sample standard deviation dropped from 98,000 down to 100 (matches the expected theoretical Poisson noise sqrt(10,000) = 100).
#     3. The new mean (9997.4) converged to match the median (10006.5) and the true Poisson mean (10,000).


# In[ ]:





# In[ ]:




