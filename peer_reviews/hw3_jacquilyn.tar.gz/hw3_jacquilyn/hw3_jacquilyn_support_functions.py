#!/usr/bin/env python
# coding: utf-8

# In[3]:


#Imported libraries
'''Included here are any libraries needed for the functions to run correctly'''

import os
import numpy
import matplotlib
import matplotlib.pyplot


# In[4]:


#Imported functions from other files


# In[5]:


#Function 1
def square(x):
    import numpy
    return numpy.square(x)

    ''' 
    Computes the square of a scalar or an array-like input of any dimension or numerical type and returns its square


    Parameters
    ----------
    x: array_like, or numerical type


    Returns
    -------
    output: array_like or single value
      the square of user's input (x). output type depends on input type


    Example
    -------
    >>> final= square(3)
    >>> print(final)
    9


    >>> a= (2, 3, 6)
    >>> square(a)
    (4, 9, 36)

    '''


#Function 2
def squareplot(low, high, num, saveplot=False):
    '''
    Plots the squares of numbers against themselves.


    Squareplot will use numbers within a specific range you give, and square
    them, then plot these squares against the original number. The graph created
    will use equally spaced points, the number of which is specified by the user's
    input, allowing the user to determine the specificity of the graph. The user
    also has the choice to save the plot as a png after the function is performed.

    
    Parameters
    ----------
    low: int
        the low end of your range
    high: int
        the high end of your range
    num: int
        The number of data points to be incuded in your range
    saveplot: {'False', 'True'}, optional
        Optional choice to save the plot


    Returns
    -------
    Graph: plot
        A plot of squared numbers vs original numbers


    Example
    -------
    >>> squareplot(0, 100, 10, True)
    
    Please enter the file name you would like to use for your plot:
    >>>Square Plot
    ###I don't understand what to put here
    

    '''
    
    import numpy
    import matplotlib
    import matplotlib.pyplot

    #Creating array x and squaring it into array y
    x= numpy.linspace(low, high, num)
    y= square(x)

    #Plotting y vs x
    matplotlib.pyplot.plot(x, y, 'X')
    
    matplotlib.pyplot.title("Square Function")
    matplotlib.pyplot.xlabel("Input")
    matplotlib.pyplot.ylabel("Output")


    #Saving plot
    if saveplot==True:
        name= input("Please enter the file name you would like to use for your plot: ")
        matplotlib.pyplot.savefig(f"{name}.pdf")
       



